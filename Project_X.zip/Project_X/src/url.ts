import type { ResolvedInput } from "./types.ts";

export const internalScheme = "myeverythingproxy:";

const looksLikeUrl =
	/^(?:(?:(?:\d{1,3}\.){3}\d{1,3}|\[[0-9a-f:.]+\]|[^\s/?#@]+\.[^\s/?#@.]{2,})(?::\d+)?(?:[/?#]\S*)?)$/iu;

const proxyableSchemes = new Set(["http:", "https:"]);

const isLoopback = (hostname: string): boolean => {
	const host = hostname.toLowerCase().replace(/^\[|\]$/g, "");
	if (host === "localhost" || host.endsWith(".localhost")) return true;
	if (host === "::1" || host === "::") return true;

	const mapped = /^::ffff:(\d{1,3}(?:\.\d{1,3}){3})$/.exec(host);
	const octets = (mapped ? mapped[1] : host).split(".");
	if (octets.length !== 4) return false;
	if (!octets.every(part => /^\d{1,3}$/.test(part) && Number(part) < 256))
		return false;

	return Number(octets[0]) === 127 || octets.join(".") === "0.0.0.0";
};
const blockedSchemes = new Set([
	"javascript:",
	"data:",
	"vbscript:",
	"file:",
	"blob:",
	"filesystem:"
]);

export const resolveInput = (
	input: string,
	searchTemplate: string
): ResolvedInput => {
	const text = String(input ?? "").trim();

	if (!text) return { url: "", kind: "empty" };

	if (text.slice(0, internalScheme.length).toLowerCase() === internalScheme) {
		return { url: text, kind: "internal" };
	}

	if (looksLikeUrl.test(text)) {
		try {
			const parsed = new URL(`https://${text}`);
			if (isLoopback(parsed.hostname))
				return { url: "", kind: "blocked" };
			if (!parsed.username && !parsed.password)
				return { url: parsed.href, kind: "url" };
		} catch {}
	}

	if (isLoopback(text.split(/[:/?#]/)[0] ?? "")) {
		return { url: "", kind: "blocked" };
	}

	if (/^[a-z][a-z0-9+.-]*:/i.test(text)) {
		try {
			const parsed = new URL(text);
			if (
				parsed.username ||
				parsed.password ||
				blockedSchemes.has(parsed.protocol) ||
				(proxyableSchemes.has(parsed.protocol) &&
					isLoopback(parsed.hostname))
			) {
				return { url: "", kind: "blocked" };
			}
			return proxyableSchemes.has(parsed.protocol)
				? { url: parsed.href, kind: "url" }
				: { url: parsed.href, kind: "external" };
		} catch {
			return { url: "", kind: "blocked" };
		}
	}

	return {
		url: searchTemplate.replace("%s", encodeURIComponent(text)),
		kind: "search"
	};
};

export const formatForDisplay = (url: string): string => {
	try {
		const parsed = new URL(url);
		if (parsed.protocol === internalScheme) return parsed.href;
		const host = parsed.host.replace(/^www\./, "");
		const rest = parsed.pathname === "/" ? "" : parsed.pathname;
		return host + rest + parsed.search + parsed.hash;
	} catch {
		return url;
	}
};

export const originOf = (url: string): string => {
	try {
		return new URL(url).origin;
	} catch {
		return "";
	}
};
